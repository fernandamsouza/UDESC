import jasmin.Main;

public class Jasmin {
    public static void main(String args[])
    { Main.main(args); }
}
