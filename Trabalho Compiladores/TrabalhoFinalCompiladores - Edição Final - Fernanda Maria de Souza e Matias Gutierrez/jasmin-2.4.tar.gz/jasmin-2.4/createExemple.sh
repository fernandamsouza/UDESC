java -jar jasmin.jar teste1.j
